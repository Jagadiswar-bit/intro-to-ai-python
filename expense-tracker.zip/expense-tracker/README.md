# Expense Tracker (Python Mini Project)

A simple command-line app to record and review daily expenses.
Built with core Python only (no external libraries).

**Author:** Jagadiswar, B.Tech CSE, Usha Rama College of Engineering and Technology

## Features

- Add an expense with name, amount and category
- View all expenses in a table
- See total spending
- See spending grouped by category
- Delete an expense
- Data is saved in `expenses.json`, so it stays after you close the program
- Input checks: invalid numbers and menu choices are handled without crashing

## Concepts used

Variables, loops, functions, lists, dictionaries, file handling (JSON), exception handling, string formatting.

## How to run

1. Install Python 3 from https://www.python.org/downloads/
2. Open a terminal in this folder
3. Run: `python expense_tracker.py`

## Sample output

```
===== Expense Tracker =====
1. Add expense
...
No.  Date        Name                Category       Amount
---------------------------------------------------------
1    2026-11-18  Notebook            books          120.00
2    2026-11-18  Bus ticket          travel          35.00
```

## Possible improvements

- Monthly reports
- Export to CSV
- A graphical interface

"""Expense Tracker - a simple command-line Python mini project.

Features: add expenses, view all, total spending, spending by category,
delete an expense. Data is saved in expenses.json so it is kept between runs.
"""

import json
import os
from datetime import date

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "expenses.json")


def load_expenses():
    """Read expenses from the file. Return an empty list if none exist yet."""
    if not os.path.exists(DATA_FILE):
        return []
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        print("Could not read the data file. Starting with an empty list.")
        return []


def save_expenses(expenses):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(expenses, f, indent=2)


def read_amount(prompt):
    """Keep asking until the user types a positive number."""
    while True:
        text = input(prompt).strip()
        try:
            value = float(text)
            if value <= 0:
                print("Amount must be greater than zero.")
                continue
            return round(value, 2)
        except ValueError:
            print("Please enter a valid number, for example 250 or 99.50")


def add_expense(expenses):
    title = input("Expense name: ").strip()
    if not title:
        print("Name cannot be empty.")
        return
    amount = read_amount("Amount (Rs): ")
    category = input("Category (food/travel/books/other): ").strip().lower() or "other"
    expenses.append(
        {"title": title, "amount": amount, "category": category,
         "date": date.today().isoformat()}
    )
    save_expenses(expenses)
    print(f"Added: {title} - Rs {amount:.2f}")


def view_expenses(expenses):
    if not expenses:
        print("No expenses recorded yet.")
        return
    print(f"\n{'No.':<5}{'Date':<12}{'Name':<20}{'Category':<10}{'Amount':>10}")
    print("-" * 57)
    for i, e in enumerate(expenses, start=1):
        print(f"{i:<5}{e['date']:<12}{e['title'][:18]:<20}{e['category'][:9]:<10}{e['amount']:>10.2f}")


def show_total(expenses):
    total = sum(e["amount"] for e in expenses)
    print(f"Total spent: Rs {total:.2f} on {len(expenses)} expense(s)")


def show_by_category(expenses):
    if not expenses:
        print("No expenses recorded yet.")
        return
    totals = {}
    for e in expenses:
        totals[e["category"]] = totals.get(e["category"], 0) + e["amount"]
    print("\nSpending by category:")
    for category, amount in sorted(totals.items(), key=lambda item: item[1], reverse=True):
        print(f"  {category:<10} Rs {amount:.2f}")


def delete_expense(expenses):
    view_expenses(expenses)
    if not expenses:
        return
    choice = input("Number to delete (or press Enter to cancel): ").strip()
    if not choice:
        return
    if choice.isdigit() and 1 <= int(choice) <= len(expenses):
        removed = expenses.pop(int(choice) - 1)
        save_expenses(expenses)
        print(f"Deleted: {removed['title']}")
    else:
        print("Invalid number.")


def main():
    expenses = load_expenses()
    menu = (
        "\n===== Expense Tracker =====\n"
        "1. Add expense\n"
        "2. View all expenses\n"
        "3. Total spending\n"
        "4. Spending by category\n"
        "5. Delete an expense\n"
        "6. Exit\n"
    )
    while True:
        print(menu)
        choice = input("Choose 1-6: ").strip()
        if choice == "1":
            add_expense(expenses)
        elif choice == "2":
            view_expenses(expenses)
        elif choice == "3":
            show_total(expenses)
        elif choice == "4":
            show_by_category(expenses)
        elif choice == "5":
            delete_expense(expenses)
        elif choice == "6":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a number from 1 to 6.")


if __name__ == "__main__":
    main()

"""Checks that the AI categorizer works on names it has never seen.

Run with:  python test_categorizer.py
"""

import unittest

from ai_categorizer import ExpenseCategorizer

# names that are NOT in the training data
UNSEEN = [
    ("chicken biryani", "food"),
    ("auto rickshaw", "travel"),
    ("maths textbook", "books"),
    ("movie night", "entertainment"),
    ("airtel recharge", "bills"),
    ("paracetamol tablets", "health"),
    ("new sneakers", "shopping"),
]


class TestCategorizer(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.ai = ExpenseCategorizer()
        cls.ai.train()

    def test_returns_valid_confidence(self):
        category, confidence = self.ai.predict("bus pass")
        self.assertTrue(0 <= confidence <= 1)
        self.assertIsInstance(category, str)

    def test_unseen_names(self):
        correct = 0
        for name, expected in UNSEEN:
            predicted, confidence = self.ai.predict(name)
            mark = "OK " if predicted == expected else "MISS"
            print(f"{mark} {name:<22} -> {predicted:<14} ({confidence:.0%})")
            correct += predicted == expected
        accuracy = correct / len(UNSEEN)
        print(f"Accuracy on unseen names: {correct}/{len(UNSEEN)} = {accuracy:.0%}")
        self.assertGreaterEqual(accuracy, 0.7)

    def test_learns_from_user_data(self):
        ai = ExpenseCategorizer()
        ai.train(extra_examples=[("kisan seeds", "farming")] * 5)
        category, _ = ai.predict("kisan seeds")
        self.assertEqual(category, "farming")


if __name__ == "__main__":
    unittest.main(verbosity=1)

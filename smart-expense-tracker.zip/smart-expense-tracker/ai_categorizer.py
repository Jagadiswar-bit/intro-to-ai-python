"""AI part of the project: predicts an expense category from its name.

How it works (supervised Machine Learning):
1. Text is turned into numbers with TF-IDF on character groups, so even
   spelling mistakes like "biriyani" still look similar to "biryani".
2. A Logistic Regression model learns which character patterns belong
   to which category.
3. For a new expense name it returns the best category and a confidence.
"""

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

from training_data import TRAINING_DATA


class ExpenseCategorizer:
    def __init__(self):
        self.model = None

    def train(self, extra_examples=None):
        """Train on the starter data plus any (name, category) pairs from the user."""
        texts, labels = [], []
        for category, phrases in TRAINING_DATA.items():
            for phrase in phrases:
                texts.append(phrase.lower())
                labels.append(category)
        for name, category in (extra_examples or []):
            texts.append(name.lower().strip())
            labels.append(category.lower().strip())

        self.model = make_pipeline(
            TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 4)),
            LogisticRegression(max_iter=1000, C=10),
        )
        self.model.fit(texts, labels)
        return len(texts)

    def predict(self, name):
        """Return (best_category, confidence between 0 and 1)."""
        text = name.lower().strip()
        probabilities = self.model.predict_proba([text])[0]
        best = probabilities.argmax()
        return self.model.classes_[best], float(probabilities[best])

    def top_predictions(self, name, n=3):
        """Return the n most likely categories with their probabilities."""
        text = name.lower().strip()
        probabilities = self.model.predict_proba([text])[0]
        order = probabilities.argsort()[::-1][:n]
        return [(self.model.classes_[i], float(probabilities[i])) for i in order]

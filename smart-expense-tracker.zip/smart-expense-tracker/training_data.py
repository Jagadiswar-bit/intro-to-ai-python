"""Starter examples used to teach the model what each category looks like.

More examples are added automatically from your own saved expenses,
so the model gets better the more you use it.
"""

TRAINING_DATA = {
    "food": [
        "lunch at canteen", "dinner", "tea", "coffee", "samosa", "biryani",
        "pizza", "groceries", "vegetables", "milk", "snacks", "breakfast idli",
        "juice", "ice cream", "restaurant bill", "chicken curry", "fruits",
        "bakery cake", "burger", "chai and biscuits",
    ],
    "travel": [
        "bus ticket", "auto fare", "train ticket", "metro card recharge",
        "petrol", "cab ride", "uber", "ola ride", "flight ticket", "bike fuel",
        "toll charges", "college bus pass", "railway reservation", "parking fee",
    ],
    "books": [
        "notebook", "pen", "textbook", "exam fee", "xerox copies", "printout",
        "stationery", "reference book", "lab record", "calculator",
        "course fee", "online course", "geometry box", "project report binding",
    ],
    "entertainment": [
        "movie ticket", "netflix subscription", "game top up", "concert",
        "cricket match", "ott subscription", "spotify", "bowling",
        "amusement park", "video game", "youtube premium", "party", "picnic",
    ],
    "bills": [
        "mobile recharge", "electricity bill", "wifi bill", "water bill",
        "dth recharge", "rent", "hostel fees", "internet recharge",
        "gas cylinder", "phone bill", "broadband", "laundry",
    ],
    "health": [
        "medicine", "doctor consultation", "pharmacy", "hospital",
        "dental checkup", "eye test glasses", "vitamins", "first aid",
        "gym membership", "blood test", "health checkup", "cough syrup",
        "tablets", "ointment", "bandage", "medical shop",
    ],
    "shopping": [
        "t-shirt", "jeans", "shoes", "headphones", "backpack", "watch",
        "phone cover", "clothes", "sandals", "earphones", "charger",
        "sunglasses", "gift for friend", "sports shoes", "slippers", "kurta",
        "trousers", "bag", "wallet", "belt",
    ],
}

# Smart Expense Tracker (AI Tools & Mini Project)

An AI-powered improvement of my earlier **Expense Tracker** Python mini project.
When you add an expense, a small Machine Learning model suggests the category
(food, travel, books, and so on). You can accept it or type your own, and the
model **learns from your choices** each time it starts.

**Author:** Jagadiswar, B.Tech CSE, Usha Rama College of Engineering and Technology

## What is new compared with the basic tracker

| Basic Expense Tracker | Smart Expense Tracker |
|-----------------------|-----------------------|
| You type the category every time | AI predicts the category from the expense name |
| No learning | Retrains on your own saved expenses |
| Plain totals | Totals plus percentage share of each category |
| No tests | Unit tests that check the AI on names it has not seen |

## How the AI works

1. The expense name is converted to numbers using **TF-IDF on character groups**, so small spelling differences (for example "biriyani") still look similar to known words.
2. A **Logistic Regression** model from Scikit-learn learns which patterns belong to which category.
3. For a new name it returns the best category with a confidence score. If the confidence is below 35%, the app says it is unsure and asks you instead of guessing.

The model is trained on about 100 starter examples in `training_data.py`, plus every expense you save.

**Measured result:** on 7 expense names that are not in the training data, the model got 6 right (86%). It wrongly labelled "new sneakers" as food, which shows the starter data is small. Adding your own expenses improves it.

## Files

| File | Purpose |
|------|---------|
| `expense_tracker.py` | Main menu-based program |
| `ai_categorizer.py` | The Machine Learning model |
| `training_data.py` | Starter examples for each category |
| `test_categorizer.py` | Tests for the AI part |
| `requirements.txt` | Libraries needed |

## How to run

```
pip install -r requirements.txt
python expense_tracker.py
```

To run the tests: `python test_categorizer.py`

## AI tools explored

I explored general-purpose AI assistants such as **ChatGPT, Google Gemini, Microsoft Copilot** and **Claude**. They are chat-based tools that answer questions and generate text and code from plain-language instructions.

| Area | How AI tools can help |
|------|-----------------------|
| Coding | Explain error messages, suggest code, write test cases, review and improve functions |
| Research | Summarise a topic, compare options, explain a concept in simple words |
| Productivity | Draft emails and notes, make study plans, turn rough points into clean documents |

**What I learned**
- A clear, specific prompt gives a much better answer than a vague one.
- AI answers can be wrong or out of date, so code must be run and tested and facts must be checked.
- AI is best used as a helper for learning and drafting, not as a replacement for understanding the code.

In this project, an AI assistant helped with planning and writing the code, and I tested the results using the unit tests above.

## Possible improvements

- Monthly reports and charts
- Export to CSV
- A web or mobile interface
- Reading a bill photo and extracting the amount

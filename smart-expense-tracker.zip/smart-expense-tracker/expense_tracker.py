"""Smart Expense Tracker - an AI-powered improvement of my Expense Tracker mini project.

New in this version: when you type an expense name, a Machine Learning model
suggests the category. You can accept it or type your own, and the model
learns from your choices every time the program starts.
"""

import json
import os
from datetime import date

from ai_categorizer import ExpenseCategorizer

DATA_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "expenses.json")
CONFIDENCE_LIMIT = 0.35      # below this the AI says it is not sure


def load_expenses():
    if not os.path.exists(DATA_FILE):
        return []
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        print("Could not read the data file. Starting with an empty list.")
        return []


def save_expenses(expenses):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(expenses, f, indent=2)


def build_ai(expenses):
    """Train the categorizer on starter data plus the user's saved expenses."""
    ai = ExpenseCategorizer()
    history = [(e["title"], e["category"]) for e in expenses]
    count = ai.train(extra_examples=history)
    print(f"AI ready: trained on {count} examples "
          f"({len(history)} from your own expenses).")
    return ai


def read_amount(prompt):
    while True:
        text = input(prompt).strip()
        try:
            value = float(text)
            if value <= 0:
                print("Amount must be greater than zero.")
                continue
            return round(value, 2)
        except ValueError:
            print("Please enter a valid number, for example 250 or 99.50")


def choose_category(ai, title):
    """Ask the AI for a suggestion; the user can accept or override it."""
    category, confidence = ai.predict(title)
    if confidence >= CONFIDENCE_LIMIT:
        print(f"AI suggests: {category} ({confidence:.0%} sure)")
        answer = input("Press Enter to accept, or type another category: ").strip().lower()
        return answer or category
    options = ", ".join(c for c, _ in ai.top_predictions(title))
    print(f"AI is not sure about '{title}' (best guesses: {options}).")
    answer = input("Category: ").strip().lower()
    return answer or "other"


def add_expense(expenses, ai):
    title = input("Expense name: ").strip()
    if not title:
        print("Name cannot be empty.")
        return ai
    amount = read_amount("Amount (Rs): ")
    category = choose_category(ai, title)
    expenses.append(
        {"title": title, "amount": amount, "category": category,
         "date": date.today().isoformat()}
    )
    save_expenses(expenses)
    print(f"Added: {title} - Rs {amount:.2f} [{category}]")
    return build_ai(expenses)          # learn from the new entry straight away


def view_expenses(expenses):
    if not expenses:
        print("No expenses recorded yet.")
        return
    print(f"\n{'No.':<5}{'Date':<12}{'Name':<20}{'Category':<14}{'Amount':>10}")
    print("-" * 61)
    for i, e in enumerate(expenses, start=1):
        print(f"{i:<5}{e['date']:<12}{e['title'][:18]:<20}{e['category'][:12]:<14}{e['amount']:>10.2f}")


def show_total(expenses):
    total = sum(e["amount"] for e in expenses)
    print(f"Total spent: Rs {total:.2f} on {len(expenses)} expense(s)")


def show_by_category(expenses):
    if not expenses:
        print("No expenses recorded yet.")
        return
    totals = {}
    for e in expenses:
        totals[e["category"]] = totals.get(e["category"], 0) + e["amount"]
    grand = sum(totals.values())
    print("\nSpending by category:")
    for category, amount in sorted(totals.items(), key=lambda item: item[1], reverse=True):
        print(f"  {category:<14} Rs {amount:>9.2f}  ({amount / grand:.0%})")


def delete_expense(expenses):
    view_expenses(expenses)
    if not expenses:
        return
    choice = input("Number to delete (or press Enter to cancel): ").strip()
    if not choice:
        return
    if choice.isdigit() and 1 <= int(choice) <= len(expenses):
        removed = expenses.pop(int(choice) - 1)
        save_expenses(expenses)
        print(f"Deleted: {removed['title']}")
    else:
        print("Invalid number.")


def try_ai():
    """Let the user test the AI without saving anything."""
    name = input("Type an expense name to test the AI: ").strip()
    return name


def main():
    expenses = load_expenses()
    ai = build_ai(expenses)
    menu = (
        "\n===== Smart Expense Tracker =====\n"
        "1. Add expense (AI suggests the category)\n"
        "2. View all expenses\n"
        "3. Total spending\n"
        "4. Spending by category\n"
        "5. Delete an expense\n"
        "6. Test the AI categorizer\n"
        "7. Exit\n"
    )
    while True:
        print(menu)
        choice = input("Choose 1-7: ").strip()
        if choice == "1":
            ai = add_expense(expenses, ai)
        elif choice == "2":
            view_expenses(expenses)
        elif choice == "3":
            show_total(expenses)
        elif choice == "4":
            show_by_category(expenses)
        elif choice == "5":
            delete_expense(expenses)
        elif choice == "6":
            name = try_ai()
            if name:
                for category, p in ai.top_predictions(name):
                    print(f"  {category:<14} {p:.0%}")
        elif choice == "7":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please enter a number from 1 to 7.")


if __name__ == "__main__":
    main()
